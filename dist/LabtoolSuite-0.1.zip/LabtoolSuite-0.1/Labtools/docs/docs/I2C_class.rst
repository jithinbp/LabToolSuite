I2C_class module
================

.. automodule:: I2C_class
    :members:
    :undoc-members:
    :show-inheritance:
