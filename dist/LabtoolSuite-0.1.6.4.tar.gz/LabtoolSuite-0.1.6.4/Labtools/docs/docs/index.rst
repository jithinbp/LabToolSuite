.. Lab ToolSuite documentation master file, created by
   sphinx-quickstart on Tue Apr 14 11:25:49 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Lab ToolSuite's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 4

   interface
   SPI_class
   I2C_class

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

